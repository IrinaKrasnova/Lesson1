package Dz5.Lesson;


public class Horse extends Animal{
    Horse (String name,float jamp,float run, float swim){
        super (name, jamp, run, swim);
    }
}