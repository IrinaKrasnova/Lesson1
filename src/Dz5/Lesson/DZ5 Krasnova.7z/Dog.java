package Dz5.Lesson;


public class Dog extends Animal{
    Dog (String name,float jamp,float run, float swim){
        super (name, jamp, run, swim);
    }
}